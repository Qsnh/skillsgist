---
name: demo-skill
description: A demo skill used by the test suite.
---

# Demo

Body text.
